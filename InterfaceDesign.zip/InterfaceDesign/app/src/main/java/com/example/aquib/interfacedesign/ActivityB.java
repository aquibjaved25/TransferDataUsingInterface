package com.example.aquib.interfacedesign;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static com.example.aquib.interfacedesign.ActivityA.valuehere;

public class ActivityB extends AppCompatActivity {

    EditText bHelloET;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);

        bHelloET = (EditText) findViewById(R.id.b_hello);
        Button bHello = (Button) findViewById(R.id.button_submit);

        bHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityA a = new ActivityA();
//                a.UpdateTextHere(bHelloET.getText().toString());

                valuehere = bHelloET.getText().toString();

                finish();
            }
        });
    }
}
