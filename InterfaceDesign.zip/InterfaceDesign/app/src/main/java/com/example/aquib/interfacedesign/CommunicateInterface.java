package com.example.aquib.interfacedesign;

/**
 * Created by Aquib on 4/22/2017.
 *
 */

public interface CommunicateInterface {

    public  void respond(String getData);
}
